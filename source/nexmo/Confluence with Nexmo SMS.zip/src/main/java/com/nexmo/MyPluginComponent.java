package com.nexmo;

public interface MyPluginComponent
{
    String getName();
}